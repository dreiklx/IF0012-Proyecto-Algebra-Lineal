# Pendientes que dependen de la docente

**Fecha:** 03-nov-2026 (revisada tras releer los PDF). **Entrega:** 11-nov-2026.

**Regla:** aquí **no** hay respuestas de la docente. Cuando llegue una, se anota con su fecha y su medio (correo, Mediación Virtual o clase), y se actualizan este archivo y `auditoria_requisitos.md`.

Se usó un solo criterio: si el enunciado oficial (OFICIAL) basta para decidir, se decide y se explica. Si no basta, el pendiente queda abierto, con una interpretación provisional.

## Organización del grupo (sin pendientes)

| Tema | Estado | Detalle |
|---|---|---|
| Grupo | **CONFIRMADO: grupo 01** | Integrantes: Derek Farley Noguera, Elmer López Hernández, Samir Sandoval Ramírez y Daniel Córdoba Arias. Entrega: `Grupo01-IF0012-Proyecto-IIC.zip` |
| Manual en otra computadora | **COMPLETADO** | El equipo confirmó el 03-nov-2026 que la aplicación funciona en otra computadora siguiendo el manual |
| Repositorio GitHub | **CREADO Y SINCRONIZADO** | Privado: `https://github.com/dreiklx/IF0012-Proyecto-Algebra-Lineal`, rama `main` |
| Invitaciones (permiso de escritura) | **ENVIADAS el 03-nov-2026; pendientes de aceptación** | `samir24cr` (GitHub lo registra como `Samir24cr`), `NaygellArias` y `ELMER100102`. Cada uno debe aceptar desde el correo o en `https://github.com/dreiklx/IF0012-Proyecto-Algebra-Lineal/invitations`. Hasta entonces, solo `dreiklx` tiene acceso efectivo |

## Resumen

| # | Pendiente | ¿Lo resuelve el enunciado? | Qué parte afecta | Riesgo si no se aclara |
|---|---|---|---|---|
| P-1 | Número de grupo | **Resuelto:** grupo 01, confirmado por el equipo | Nombre del ZIP | Ninguno |
| P-2 | Uso de IA | **Sí:** no hay ningún requisito de autorización previa; se exige declarar y defender | Integridad académica (PROG p. 7, §6.2) | Bajo. **No bloquea la entrega**; se mantiene la declaración |
| P-3 | Caso de validación obligatorio | No: la docente lo debe entregar (OFICIAL p. 3); no está en ningún PDF | Rúbrica «Casos de prueba» (3 %) | Medio |
| P-4 | Significado de «error final» | **Sí: la lámina S9-05/10 p. 17 lo define** | M4-07 | **Resuelto** |
| P-5 | Alcance del radio espectral | En parte | M4-05 e incentivo I-05 | Medio |
| P-6 | NumPy como dependencia interna de Streamlit y Matplotlib | **Sí**, en lo esencial | R-02, R-03 | Bajo |
| P-7 | Interpretación de la perturbación porcentual | **Sí**, en lo esencial | M2-03 | Bajo |
| P-8 | Comparación esperada en el precondicionamiento | **En gran parte:** la lámina S9-05/10 p. 21 dice qué comparar (κ y ρ de A frente a B) | Incentivo I-02 (hasta 1.5 %) | Bajo. **Implementado el 03-nov**; queda por ver si la docente acepta el resultado (efecto nulo en Jacobi, GS y SOR) |

---

## P-1. Número definitivo del grupo — RESUELTO

- **Confirmado por el equipo el 03-nov-2026:** el proyecto es del **grupo 01**, integrado exclusivamente por Elmer López Hernández, Derek Farley Noguera, Daniel Córdoba Arias y Samir Sandoval Ramírez.
- **Evidencia documental coincidente:** el horario del grupo (L 16:00-17:50 y M 13:00-15:50) corresponde en el programa (PROG p. 9, Sede del Caribe, Aula de Siquirres) al grupo 01, de la profesora Imelda Sáenz Pineda.
- **Nombre de entrega:** `Grupo01-IF0012-Proyecto-IIC.zip`, generado con `python empaquetar.py 01`.

## P-2. Uso de inteligencia artificial — DECLARADO; no hay un requisito de autorización previa

**Qué dicen los documentos** (releídos el 03-nov-2026):

| Documento | Texto (literal) | Qué exige |
|---|---|---|
| Enunciado del proyecto (OFICIAL), pp. 1-5 | No menciona la inteligencia artificial. Lo más cercano: «El código externo no citado o copiado será tratado de acuerdo con la normativa académica aplicable» y «Si se utiliza una librería únicamente para visualización, interfaz o manejo de archivos, debe indicarse en la documentación» | **Citar y declarar**, no pedir permiso |
| Programa del curso (PROG p. 7, §6.2, «Consideraciones académicas y éticas») | «En caso de detectarse una falta, como copia o plagio, […] mediante el uso indebido de herramientas de inteligencia artificial no autorizadas, se procederá de acuerdo con lo estipulado en el Reglamento de Orden y Disciplina Estudiantil» | Prohíbe el uso **indebido** como forma de copia o plagio. **No establece ningún trámite de autorización previa por escrito** |
| Tarea II y láminas del curso | Sin disposiciones sobre IA (búsqueda en el texto) | — |

**Conclusión:**

- No existe un requisito explícito de autorización previa, así que **deja de ser un bloqueo de entrega**.
- Lo que sí rige:
  1. no presentar como propio, sin declararlo, un trabajo hecho con IA (honestidad académica, §6.2);
  2. que cada integrante comprenda, explique y defienda el trabajo (OFICIAL p. 3: defensa individual con caso no preparado; lista de la p. 5: «Cada integrante está preparado para explicar y defender matemáticamente el trabajo»).

**Lo que se hace:**

- **Se conserva la declaración** de `docs/herramientas_y_bibliotecas.md` §4: Claude Code y ChatGPT, y para qué se usaron. Esa declaración se entrega en el ZIP.
- **No se afirma** que la docente haya autorizado el uso: no hay ninguna respuesta suya al respecto.

**Riesgo residual (bajo):** §6.2 habla de herramientas «no autorizadas» sin definir cuáles lo están. Si el grupo quiere eliminar toda duda, puede **informar** a la docente, sin que sea un requisito de entrega:

> «Profesora, para su conocimiento: en el proyecto final usamos asistentes de inteligencia artificial (Claude Code y ChatGPT) como apoyo en la programación y la revisión, y lo declaramos en docs/herramientas_y_bibliotecas.md. Todos los integrantes estudiamos el código para defenderlo. Si tiene alguna indicación sobre cómo declararlo, la aplicaremos.»

## P-3. Caso de validación obligatorio

**Qué dice exactamente el enunciado** (releído el 03-nov-2026; no hay otro documento que lo trate):

| Página | Texto (literal) | Qué implica |
|---|---|---|
| OFICIAL p. 1, entregables | «Carpeta de casos de prueba, incluyendo los casos obligatorios indicados por la docente» | El caso o los casos deben ir **dentro de la carpeta de casos de prueba del ZIP** |
| OFICIAL p. 3, §4 | «La docente proporcionará al menos un caso de validación obligatorio antes de la entrega» | Lo **proporciona la docente**: no lo diseña el grupo. Puede ser más de uno («al menos») |
| OFICIAL p. 3, §4 | «la aplicación deberá superar casos de prueba comunes para verificar que los algoritmos no estén construidos para un único conjunto de datos» | El propósito es comprobar que la aplicación resuelve **datos que el grupo no eligió** |
| OFICIAL p. 3, §4 | «Las diferencias numéricas deberán justificarse mediante la tolerancia utilizada y no mediante redondeos arbitrarios» | Si nuestro resultado difiere del de la docente en los decimales, hay que explicarlo con ε (iterativos) o mostrar que el nuestro es exacto (directos) |
| OFICIAL p. 4, rúbrica «Casos de prueba» (3 %) | Excelente: «Casos documentados y aplicación supera el caso obligatorio». Insuficiente: «No presenta pruebas o falla el caso obligatorio» | Es el criterio que acredita: **3 % de la nota del proyecto** |
| OFICIAL p. 5, lista final | «Se incluyeron casos de prueba y se verificó el caso obligatorio» | Debe quedar **evidencia de la verificación** en la entrega |

**Lo que el enunciado NO dice** (y por eso no se puede suponer):

- qué módulo o módulos cubre;
- en qué formato llegan los datos;
- si la docente da también la salida esperada;
- la fecha y el medio de entrega.

**Estado (12-nov-2026):**

- El enunciado **sí contempla** un caso de validación proporcionado por la docente (OFICIAL p. 3, §4; referencias en las páginas 1, 4 y 5 indicadas arriba).
- El equipo **no ha recibido** ese caso. La docente no lo ha entregado.
- **No se inventa** un caso ni se atribuye a la profesora. Los casos de la carpeta casos_prueba/ son casos internos de Ax, independientes del caso oficial.
- **No es un error de implementación** de Ax: es un entregable externo que depende de la docente. Así se documenta en la matriz de rúbrica.
- Búsqueda: texto de los 18 PDF (`pdftotext`) y OCR de las 457 páginas. Ningún archivo contiene un caso obligatorio.

**Qué hay que hacer cuando llegue** (ya está preparado):

1. Copiar la entrada exacta en `casos_prueba/caso_obligatorio.md`, con la fecha y el medio por el que llegó.
2. Si la docente da la salida esperada, anotarla tal cual. Si no la da, calcularla de forma independiente (a mano, con Cramer o con la adjunta, como en los demás casos).
3. Ejecutarla en la aplicación y registrar el resultado obtenido en la misma tabla: entrada, salida esperada, resultado obtenido y si coincide.
4. Crear la prueba automática `tests/test_caso_obligatorio.py`, que reproduzca exactamente los datos y compare con la salida esperada (con la tolerancia indicada si es iterativo).
5. Ejecutar todas las pruebas y la auditoría, regenerar el ZIP y subir los cambios a GitHub.

**Pregunta exacta para la docente:** «Profesora, el enunciado indica que usted proporcionará al menos un caso de validación obligatorio antes de la entrega. ¿Podría indicarnos cuándo y por qué medio lo publicará, a qué módulo o módulos corresponde, y si incluye la salida esperada y la tolerancia que debemos usar? ¿Debemos entregar en el ZIP alguna evidencia en un formato particular?»

## P-4. Significado de «error final» — RESUELTO con el material de la docente

- **Evidencia (releída el 03-nov-2026):** la lámina S9-05/10 p. 17 (diapositiva 13, «Comparación de Jacobi, Gauss-Seidel y SOR en un sistema disperso») tiene una tabla con la columna **«Error final (‖x⁽ᵏ⁾ − x‖∞)»**. La p. 16 (diapositiva 12) usa la misma columna.
- **Qué hace la aplicación:** la tabla de comparación tiene la columna «Error final e = ‖x⁽ᵏ⁾ − x*‖∞», con x* la solución exacta obtenida por Gauss. Es la misma definición. Desde el 03-nov, e_k es además la primera métrica de la gráfica comparativa, como en la lámina («Evolución del error»).
- **No hace falta preguntar.** Se siguen mostrando d y r como información complementaria.

## P-5. Alcance del radio espectral

- **Qué resuelve el enunciado:** OFICIAL p. 2 pide calcular ρ(T) «cuando el procedimiento estudiado lo permita, mediante los procedimientos estudiados en el curso». Esto autoriza a **no** calcularlo cuando el procedimiento no lo permite. Por eso el límite n ≤ 8 y la respuesta «indeterminado» con autovalores múltiples son coherentes con el texto.
- **Qué no resuelve:**
  - El procedimiento del curso es det(T − λI) = 0 por Sarrus (3×3) y luego hallar las raíces (S9-05/10 pp. 32-34; S9-07/10).
  - Para n ≤ 3 el polinomio que calcula la aplicación (Faddeev-LeVerrier) es **idéntico** al de Sarrus; hay una prueba que lo comprueba.
  - En cambio, para hallar las raíces de una cúbica y para n > 3 se usa Durand-Kerner, que **no se vio en clase**.
  - El programa (PROG 4.3) menciona el método de la potencia, pero no hay material de clase sobre él en la carpeta.
- **Qué afecta:** M4-05 y la defensa del incentivo I-05.
- **Interpretación provisional:** mantener la implementación actual, que es correcta y está verificada, y presentarla como una extensión.
  - Faddeev-LeVerrier produce el mismo polinomio que Sarrus.
  - Durand-Kerner es un método propio de aproximación de raíces, cuyo resultado se verifica con |p(λ)| ≈ 0 y con Σλ = traza(T).
- **Pregunta exacta:** «Profesora, para el radio espectral usamos el polinomio característico det(T − λI) como en clase. Para matrices 3×3 lo obtenemos exactamente igual que con Sarrus, pero para hallar sus raíces (que pueden ser complejas) y para n > 3 implementamos nosotros mismos los métodos de Faddeev-LeVerrier y Durand-Kerner. ¿Es aceptable, o prefiere que limitemos el cálculo a n ≤ 3?»

## P-6. NumPy como dependencia interna de Streamlit y Matplotlib

- **Qué resuelve el enunciado:**
  - OFICIAL p. 1 prohíbe «utilizar librerías o funciones que implementen directamente los métodos solicitados». También permite usar bibliotecas «únicamente para visualización, interfaz o manejo de archivos», siempre que se indiquen en la documentación.
  - **Ningún archivo del proyecto importa NumPy** (comprobado el 02-nov con una búsqueda en todos los `.py`). NumPy solo se instala porque Streamlit y Matplotlib lo necesitan internamente.
  - Eso no es «utilizar» NumPy para los métodos. **Se considera resuelto por el propio enunciado.**
- **Qué afecta:** R-02 y R-03. Está documentado en `docs/herramientas_y_bibliotecas.md`.
- **Pregunta (opcional, para mayor seguridad):** «Profesora, nuestro código no usa NumPy, pero Streamlit y Matplotlib lo instalan como dependencia interna. ¿Hay algún inconveniente?»

## P-7. Interpretación de la perturbación porcentual

- **Qué resuelve el enunciado:** OFICIAL p. 2 pide «una perturbación controlada en el vector b (por valor absoluto o porcentaje)», sin precisar más. La aplicación usa Δbᵢ = (p/100)·bᵢ en cada componente, y también acepta un vector de porcentajes.
- **Por qué esta lectura no pierde nada:**
  - Con un único porcentaje p, Δb = (p/100)·b, de modo que ‖Δb‖∞/‖b‖∞ = |p|/100 exactamente.
  - Es el mismo error relativo que daría la otra lectura posible («perturbar b en un p % de su norma»).
  - El dato que pide el enunciado, ‖Δb‖∞/‖b‖∞, coincide en ambas lecturas. Lo único que cambia es la dirección de Δb.
  - Límite: una componente bᵢ = 0 no se perturba en modo porcentual. Para eso existe el modo absoluto.
- **Qué afecta:** M2-03 (`construir_delta_b`).
- **Estado:** resuelto con la interpretación documentada.
- **Pregunta (opcional):** «Profesora, en la perturbación porcentual de b aplicamos el porcentaje a cada componente (Δbᵢ = p/100·bᵢ). ¿Le parece adecuado?»

## P-8. Comparación esperada en el incentivo de precondicionamiento — IMPLEMENTADO

- **Qué dice el material (releído el 03-nov-2026, S9-05/10 pp. 21-23, diapositivas 17-19):**
  - M = D; se resuelve M⁻¹Ax = M⁻¹b aplicando «el método iterativo (Jacobi, Gauss-Seidel, SOR, etc.)».
  - Un buen precondicionador busca ρ(B) < ρ(A) y κ(B) < κ(A), con B = M⁻¹A.
  - La diapositiva 19 muestra a Jacobi «con precondicionamiento» convergiendo más rápido.
- **Qué se implementó** (`algebra/modulo_IV_iterativos/precondicionamiento.py`, pestaña «Precondicionamiento diagonal»):
  - exactamente esa comparación: κ∞(A) frente a κ∞(B), y los autovalores y ρ de A y de B;
  - las iteraciones de Jacobi, GS, SOR y Richardson sobre los dos sistemas;
  - la comparación exacta de las matrices de iteración.
- **Resultado:** con M = D, Jacobi, GS y SOR **no cambian** (T̃ = T, c̃ = c; demostración en guia_matematica §10). La aplicación lo muestra con evidencia, en vez de copiar la tabla de la diapositiva 19, que no es reproducible. Donde M = D sí tiene efecto (κ cuando la diagonal no es uniforme, residuo y Richardson), se muestra.
- **Riesgo:** que la docente esperara ver una aceleración de Jacobi. La respuesta preparada es la demostración de que T̃ = T, que se puede comprobar en vivo en la aplicación.
- **Pregunta (opcional, para comunicarlo con respeto):** «Profesora, al implementar el precondicionador diagonal comprobamos que con M = D las iteraciones de Jacobi, Gauss-Seidel y SOR no cambian, porque la matriz de iteración es la misma. Por eso mostramos también κ(D⁻¹A) y el método de Richardson, donde el efecto sí aparece. ¿Le parece adecuada esta comparación?»
